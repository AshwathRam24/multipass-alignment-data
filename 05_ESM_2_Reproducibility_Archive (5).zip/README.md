# Reproducibility archive: Online Resource 2

**A blind subspace in position-only alignment sensing of a Fourier-based multipass
amplifier, and its removal by far-field detection**

This archive contains the analysis scripts, digitized data, stored numerical results
and figures that accompany the article. The notebook also retains earlier development
material and a historical manuscript template; these are not the submitted manuscript.

## Disk-tilt convention

**c_disk = 2.** The disk parameter is the *mechanical* tilt, so it shares its coordinate
with the gain tolerance of Ref. [7], which states θ = 2φ and writes its Eq. (16) in φ.
The article analyses set this convention explicitly. The convention-comparison script
also evaluates the earlier branch for reference.

The study notebook `notebooks/amplifier_observability.ipynb` was executed during an earlier
phase of the work under a different decision, which it records internally as
`disk_kick_convention = 1`. That decision is superseded. The notebook is included only as
the source of the forward optical model, which is convention-independent: every script
imports the model definitions from it and then sets c_disk = 2 before computing anything.
No result in the article is read from the notebook's own stored outputs.

## Requirements

Python 3.10+, numpy, scipy, matplotlib, nbformat. See `requirements.txt`.
No GPU or network connection is needed after installing the dependencies.
The scripts set their default paths automatically. The original archive estimates
a total runtime of about 20 minutes; runtime depends on the computer.

## Reproducing the article

Run from the archive root, in this order. Paths resolve from each script's own location,
so any working directory works.

    python3 scripts/v5_structure.py        # rank, singular spectrum, null support   (~1 min)
    python3 scripts/v4_closed_form.py      # exact blind mode, Eq. (3)               (~1 min)
    python3 scripts/v4_connectors.py       # connector generality controls           (~2 min)
    python3 scripts/farfield_opt.py        # structural criterion, augmented rank    (~1 min)
    python3 scripts/v5_reliability.py      # precision, reliability, WLS Monte Carlo (~4 min)
    python3 scripts/v4_convention.py       # both convention branches                (~2 min)
    python3 scripts/v4_selection.py        # plane selection + verification draws    (~5 min)
    python3 scripts/run_mismatch.py        # robustness decomposition                (~3 min)
    python3 scripts/make_paper_figures.py  # figures 1-5                             (~1 min)
    python3 scripts/verify_manuscript_claims.py   # checks 56 assertions          (instant)

The final command checks 56 assertions against the files in `run_artifacts/`, covering
rank, nullity, the closed-form residual, connector controls, the rank criterion,
precision, reliability, sensor selection and mismatch decomposition. Each assertion
identifies the relevant article section, table or figure. The command exits with a
nonzero status if any assertion fails.

Running the verifier alone checks the stored results; it does not rerun the analyses.
Run the preceding commands first to verify newly computed results.

`make_paper_figures.py` recomputes the validation metrics from the model rather than
reading them from a file, and must print `0.0961 / 0.9982` and `0.0831 / 0.9982`.

## What produces what

| Article item | Artifact | Script |
|---|---|---|
| Fig. 1, Table 1 | `data/digitized_schuhmann_fig4.csv` | `make_paper_figures.py` (recomputes metrics) |
| Sect. 3.2, Fig. 2a | `run_artifacts/structure_c2.json` | `v5_structure.py` |
| Eq. (3), Fig. 2b, Table S2 | `run_artifacts/null_closed_form.json`, `null_vector_x.npy` | `v4_closed_form.py` |
| Sect. 3.4, Fig. 2c, Table S3 | `run_artifacts/v4_generality.json` | `v4_connectors.py` |
| Table 2, Fig. 3a, Table S4 | `run_artifacts/rank_criterion.json` | `farfield_opt.py` |
| Table 3, Fig. 3b, Table S4b | `run_artifacts/v5_reliability.json` | `v5_reliability.py` |
| Sect. 2.3 alternative branch, Sect. S9 | `run_artifacts/v4_units.json` | `v4_convention.py` |
| Table 5, Fig. 4, Table S5 | `run_artifacts/v4_select.json` | `v4_selection.py` |
| Table 6, Fig. 5, Sect. S6 | `run_artifacts/mismatch_decomposition.json` | `run_mismatch.py` |

`scripts/audit_setup.py` is the shared loader (it execs the notebook's definition cells and
exposes the model); it is not run directly. `scripts/angle_probe.py` provides
`jacobian_pos_ang` and is imported by several scripts; it can also be run on its own.

## Determinism

A single global seed derives every named random-number stream. The selection experiment
uses common random numbers across subsets and a separate, disjoint stream for the 100 000
independent verification draws. The reliability Monte Carlo uses its own fixed seed.
Re-running any script reproduces all reported scientific quantities to the stated precision; quantities that are numerically zero may vary at floating-point roundoff.

## Digitized data

`data/digitized_schuhmann_fig4.csv` carries columns `curve` (`disk50`, `input100`, or the
landmark rows `landmark_disk` and `landmark_M1a`), `z_source` (horizontal coordinate in the
published figure's own units) and `excursion_m` (metres). Digitization was by point
sampling from figure 4 of Ref. [7] with no smoothing, rescaling or normalization. That
figure is itself a published ABCD calculation, not a measurement; comparison uses
horizontal landmark registration only, and no vertical amplitude was ever fitted.
