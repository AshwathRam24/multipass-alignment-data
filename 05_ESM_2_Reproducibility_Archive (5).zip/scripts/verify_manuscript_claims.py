#!/usr/bin/env python3
"""Check the article's numerical assertions against files in run_artifacts/.

Run after the analysis scripts to check newly generated results. Running this script
alone checks the stored files and does not rerun the analyses. A failed assertion
produces a nonzero exit status. Each assertion identifies its article location.

    python3 scripts/verify_manuscript_claims.py
"""
import json, os, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
A = lambda n: json.load(open(os.path.join(ROOT, "run_artifacts", n)))

FAIL = []
N = [0]
def check(where, desc, got, want, tol=0.0):
    N[0] += 1
    ok = abs(got - want) <= tol if isinstance(want, (int, float)) and not isinstance(want, bool) \
         else got == want
    print(f"  {'PASS' if ok else 'FAIL'}  {where:<12} {desc:<48} got {got!r}")
    if not ok:
        FAIL.append(f"{where}: {desc} - got {got!r}, expected {want!r} (tol {tol})")

print("Checking article claims against the files in run_artifacts/\n")

# ---------------------------------------------------------------- convention
for name in ("structure_c2.json", "null_closed_form.json"):
    d = A(name)
    check("convention", f"{name} is c_disk = 2", d["c_disk"], 2.0)

# ------------------------------------------------------- Sect. 3.2, Fig. 2a
s = A("structure_c2.json")
check("Sect. 3.2", "Jacobian shape 40 x 38", tuple(s["shape"]), (40, 38))
check("Sect. 3.2", "rank = 36", s["rank"], 36)
check("Sect. 3.2", "nullity = 2", s["nullity"], 2)
check("Sect. 3.2", "34 of 38 parameters have null support", s["n_params_with_null_support"], 34)
check("Fig. 2a",   "smallest observable mode 3.8e-5", s["sigma36_over_sigma1"], 3.83e-5, 0.05e-5)
check("Fig. 2a",   "blind pair below 1e-16", max(s["sigma37_over_sigma1"], s["sigma38_over_sigma1"]) < 1e-16, True)
check("Fig. 2a",   "gap spans >= 11 orders",
      s["sigma36_over_sigma1"] / s["sigma37_over_sigma1"] > 1e11, True)

# ------------------------------------------------------ Eq. (3), Fig. 2b, S4
c = A("null_closed_form.json")
check("Eq. (3)", "closed-form residual, x axis < 1e-15", c["residual_x"] < 1e-15, True)
check("Eq. (3)", "closed-form residual, y axis < 1e-15", c["residual_y"] < 1e-15, True)
check("Eq. (3)", "principal cosine with numerical null = 1", c["min_principal_cosine"], 1.0, 1e-9)
check("Sect. 3.3", "out/in ratio equals eta_j to < 1e-12", c["max_ratio_error_vs_eta"] < 1e-12, True)
check("Sect. 3.3", "array coefficient sum near -8", c["array_coefficient_sum"], -8.0, 1e-4)

# ------------------------------------------------- Proposition, Sect. 3.4, Fig. 2c
g = A("v4_generality.json")["connector_generality"]
check("Sect. 3.4", "Fourier connector rank 36", g["fourier_rank"], 36)
check("Sect. 3.4", "every generalized-Fourier connector gives rank 36",
      all(x["rank"] == 36 for x in g["generic"]), True)
check("Sect. 3.4", "at least 8 tested connectors are non-periodic",
      sum(1 for x in g["generic"] if not x["M4_is_identity"]) >= 8, True)
check("Sect. 3.4", "relay B=0 rank 28 (nullity 10)", g["identity_B0_rank"], 28)
check("Sect. 3.4", "relay -I rank 28", g["minus_identity_B0_rank"], 28)

# ------------------------------------------------- Table 2, Fig. 3a, Sect. 4.2
rc = A("rank_criterion.json")["by_class"]
inc = rc["incoming array"]
oth = [x for k, v in rc.items() if k != "incoming array" for x in v]
check("Table 2", "8 incoming array planes", len(inc), 8)
check("Table 2", "every incoming plane has rank gain 2", all(x["rank_gain"] == 2 for x in inc), True)
check("Table 2", "every other plane has rank gain 0", all(x["rank_gain"] == 0 for x in oth), True)
check("Fig. 3a", "separation exceeds 10 orders of magnitude",
      min(x["rel_norm"] for x in inc) / max(x["rel_norm"] for x in oth) > 1e10, True)

# --------------------------------------------- Table 3, Fig. 3b, Sect. 4.3
r = A("v5_reliability.json")
check("Table 3", "tolerance 9.69 urad", r["tolerance_urad"], 9.692, 0.001)
check("Table 3", "one channel sigma 12.40 urad", r["1"]["sigma_x_urad"], 12.401, 0.01)
check("Table 3", "two channels sigma 8.63 urad", r["2"]["sigma_x_urad"], 8.629, 0.01)
check("Sect. 4.3", "two channels put sigma below tolerance",
      r["2"]["sigma_x_urad"] < r["tolerance_urad"], True)
check("Sect. 4.3", "two channels reliability 0.739 per axis", r["2"]["P_one_axis"], 0.7386, 0.001)
check("Sect. 4.3", "two channels reliability 0.470 two-axis", r["2"]["P_two_axis"], 0.4700, 0.002)
check("Sect. 4.3", "90 % one-axis needs 5 channels", r["k_for_90_one-axis"], 5)
check("Sect. 4.3", "90 % two-axis needs 8 channels", r["k_for_90_two-axis"], 8)
check("Sect. 4.3", "95 % one-axis needs 6 channels", r["k_for_95_one-axis"], 6)
check("Sect. 4.3", "95 % two-axis needs 10 channels", r["k_for_95_two-axis"], 10)
check("Fig. 3b", "Monte Carlo matches benchmark, one axis",
      r["max_benchmark_vs_mc_deviation"]["one_axis"] < 0.005, True)
check("Fig. 3b", "Monte Carlo matches benchmark, two axis",
      r["max_benchmark_vs_mc_deviation"]["two_axis"] < 0.010, True)

# ------------------------------------------------------------------ Table 4
# The three-requirement summary: identifiability, precision, reliability.
check("Table 4", "identifiability: 1 channel, at an incoming array plane",
      sum(1 for x in inc if x["rank_gain"] == 2), 8)
check("Table 4", "precision: 2 channels put sigma below tolerance",
      r["2"]["sigma_x_urad"] < r["tolerance_urad"] <= r["1"]["sigma_x_urad"], True)
check("Table 4", "reliability 90 %: 5 per axis, 8 two-axis",
      (r["k_for_90_one-axis"], r["k_for_90_two-axis"]), (5, 8))
check("Table 4", "reliability 95 %: 6 per axis, 10 two-axis",
      (r["k_for_95_one-axis"], r["k_for_95_two-axis"]), (6, 10))

# ------------------------------------------------------- Table 5, Fig. 4, S6
sel = A("v4_select.json")
check("Table 5", "60 249 subsets enumerated",
      sum(sel[f"k{k}"]["n_total"] for k in (3, 4, 5, 6)), 60249)
for k, want in ((3, 0.6783), (4, 0.8080), (5, 0.8820), (6, 0.9125)):
    check("Table 5", f"k={k} selection score", sel[f"k{k}"]["operational_best"]["acc_select"], want, 0.0006)
for k in (3, 4, 5):
    check("Sect. 5", f"E-optimal IS the optimum at k={k}", sel[f"k{k}"]["E_optimal"]["operational_rank"], 1)
check("Sect. 5", "E-optimal ranks 10th at k=6", sel["k6"]["E_optimal"]["operational_rank"], 10)
for k in (4, 5):
    check("Sect. 5", f"D-optimal outside top 700 at k={k}",
          sel[f"k{k}"]["D_optimal"]["operational_rank"] > 700, True)
check("Sect. 5", "verification within 0.6 pp of selection",
      max(abs(sel[f"k{k}"]["operational_best"]["acc_verify"]
              - sel[f"k{k}"]["operational_best"]["acc_select"]) for k in (3, 4, 5, 6)) <= 0.006, True)

# ---------------------------------------------------------- Table 6, Fig. 5
m = A("mismatch_decomposition.json")
check("Table 6", "artifact is c_disk = 2", m["c_disk"], 2.0)
check("Table 6", "unperturbed reference 0.810",
      m["reference (no perturbation, nominal noise)"]["mean_acc"], 0.8101, 0.001)
check("Table 6", "geometry moderate 0.150",
      m["model mismatch only, moderate"]["mean_acc"], 0.1498, 0.001)
check("Sect. 6", "geometry spread comparable to mean",
      m["model mismatch only, moderate"]["sd_across_models"]
      > 0.5 * m["model mismatch only, moderate"]["mean_acc"], True)
check("Sect. 6", "noise-only spread is small relative to geometry",
      m["detector noise only, x5"]["sd_across_models"]
      < m["model mismatch only, moderate"]["sd_across_models"], True)

print()
if FAIL:
    print(f"{len(FAIL)} CLAIM(S) NO LONGER MATCH THE ARTIFACTS:\n")
    for f in FAIL:
        print("  -", f)
    sys.exit(1)
print(f"All {N[0]} assertions passed. The checked article quantities "
      "match the files in run_artifacts/.")
