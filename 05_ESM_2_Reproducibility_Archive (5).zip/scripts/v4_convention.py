"""v4: source-consistent mechanical-tilt convention (c_disk = 2, theta = 2 phi),
far-field bounds in mechanical tilt, selection re-run, fresh-draw verification."""
import os, sys
from pathlib import Path
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))
os.environ.setdefault("NB", str(ROOT / "notebooks" / "amplifier_observability.ipynb"))
exec(open(HERE / "audit_setup.py").read())
import angle_probe as _apf
from angle_probe import jacobian_pos_ang
import numpy as np, json, dataclasses, itertools, time
_apf.ns=ns; _apf.np=np
seq2=[dataclasses.replace(e,c_x=2.0,c_y=2.0) if (e.kind=="tiltpoint" and e.name=="disk") else e for e in seq]
out={"convention":"c_disk = 2 (source: theta = 2 phi); disk parameter is the MECHANICAL tilt",
     "tolerance_urad":round(TOL*1e6,4)}

# ---- Fig. 4 amplitude implication ----
import csv
rows=list(csv.DictReader(open(DATA_CSV)))
g=lambda c: np.array([[float(r["z_source"]),float(r["excursion_m"])] for r in rows if r["curve"]==c])
lm=np.sort(g("landmark_disk")[:,0]); d=g("disk50"); o=np.argsort(d[:,0])
dig=np.interp(lm,d[o,0],d[o,1])
for phi in (50e-6, 25e-6):
    m=np.asarray(ns["ideal_station_model"](theta_disk=phi,c_disk=2.0)).ravel()[0::2]
    nr=np.sqrt(np.mean((m-dig)**2))/np.max(np.abs(dig)); r=np.corrcoef(m,dig)[0,1]
    print(f"  c_disk=2, phi={phi*1e6:.0f} urad : NRMSE {nr:.4f}  r {r:.4f}")
    out[f"fig4_c2_phi{int(phi*1e6)}"]={"nrmse":round(float(nr),4),"r":round(float(r),4)}

# ---- far-field bounds in mechanical disk tilt ----
Jp,Ja,snames=jacobian_pos_ang(plist,seq2,CFG)
di=[i for i,q in enumerate(plist) if q[0]=="disk"]
inc=[i for i,n in enumerate(snames) if n.startswith("array_") and int(n[-2:])%2]
def bound(pl,f=4.0,sc=5e-6):
    sa=sc/f; r=[Jp]; s=[sig]
    for p in pl: r.append(Ja[2*p:2*p+2]); s.append(np.full(2,sa))
    Js=np.vstack(r)/np.concatenate(s)[:,None]
    sv=np.linalg.svd(Js,compute_uv=False)
    if sv[-1]<=sv[0]*1e-10: return None
    return float(np.sqrt(np.diag(np.linalg.inv(Js.T@Js)))[di].max()*1e6)
print("\n=== far-field, MECHANICAL disk tilt (tolerance %.2f urad) ===" % (TOL*1e6))
ff={}
for k in range(1,9):
    t0=time.time(); best=(1e18,None)
    for c in itertools.combinations(range(len(snames)),k):
        b=bound(c)
        if b is not None and b<best[0]: best=(b,c)
    ff[k]={"best_bound_urad":round(best[0],3),"planes":[snames[i] for i in best[1]],
           "first_k_incoming_urad":round(bound(inc[:k]),3) if bound(inc[:k]) else None,
           "meets_tolerance":bool(best[0]<TOL*1e6)}
    print(f"  k={k}: optimized {best[0]:7.3f}  first-{k}-incoming {ff[k]['first_k_incoming_urad']:7.3f}"
          f"  {'<= TOLERANCE' if ff[k]['meets_tolerance'] else ''}   {[snames[i] for i in best[1]]}",flush=True)
out["farfield_mechanical"]=ff
out["eight_incoming_f_inf"]=round(bound(inc,1e6),4)
print("  eight incoming, f -> inf :", out["eight_incoming_f_inf"], "urad")
json.dump(out,open(artifact("v4_units.json"),"w"),indent=1)
