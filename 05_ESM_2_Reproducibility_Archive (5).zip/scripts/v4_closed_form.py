"""EXACT blind direction under the adopted convention c_disk = 2 (mechanical tilt).
Writes run_artifacts/null_closed_form.json and null_vector_x.npy."""
import os, sys
from pathlib import Path
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))
os.environ.setdefault("NB", str(ROOT / "notebooks" / "amplifier_observability.ipynb"))
exec(open(HERE / "audit_setup.py").read())
import numpy as np, json, dataclasses
C_DISK = 2.0
seq2=[dataclasses.replace(e,c_x=C_DISK,c_y=C_DISK) if (e.kind=="tiltpoint" and e.name=="disk") else e for e in seq]
J2=ns["analytic_jacobian"](plist,seq2,CFG)
wR,_=ns["aligned_beam_chain"](seq2,CFG); W=CFG.W_aperture_m; a=0.2486
eta=np.array([W**2/(w**2+W**2) for w,R in wR])
ef =np.array([W**2/(w**2+W**2)-a*(1-W**2/(w**2+W**2))/R for w,R in wR])
cA={"x":2.0,"y":float(np.sqrt(2))}; P=len(plist); nrm=np.linalg.norm(J2,ord=2)
out={"c_disk":C_DISK,"eta_per_pass":eta.tolist(),"eta_eff_per_pass":ef.tolist(),
     "connector_before_pass":["F","S","F","S","F","S","F","S"]}
def build(ax):
    v=np.zeros(P)
    for i,p in enumerate(plist):
        if p[1]!=ax: continue
        if p[0]=="disk": v[i]=1.0
        elif p[0].startswith("array_"):
            k=int(p[0][-2:]); j=(k-1)//2
            v[i]=(-C_DISK/(cA[ax]*(1+ef[j]))) if k%2 else (-C_DISK*eta[j]/(cA[ax]*(1+ef[j])))
    return v
for ax in ("x","y"):
    v=build(ax); out["residual_"+ax]=float(np.linalg.norm(J2@v)/(nrm*np.linalg.norm(v)))
    print(f"axis {ax}: relative residual {out['residual_'+ax]:.3e}")
vx=build("x")
out["phi_in_per_pass"]=[float(-C_DISK/(2*(1+e))) for e in ef]
out["phi_out_per_pass"]=[float(-C_DISK*g/(2*(1+e))) for g,e in zip(eta,ef)]
out["array_coefficient_sum"]=float(sum(vx[i] for i,p in enumerate(plist) if p[0].startswith("array_")))
out["collimated_limit_sum"]=float(-8*C_DISK/2.0)
ps=np.array([ns["prior_scale"](p[0]) for p in plist])
U,S,Vt=np.linalg.svd((J2/sig[:,None])*ps[None,:]); N=Vt[-2:].T
Q,_=np.linalg.qr(np.stack([build("x"),build("y")],1)/ps[:,None])
out["min_principal_cosine"]=float(np.linalg.svd(Q.T@N,compute_uv=False).min())
dix=[j for j,q in enumerate(plist) if q[0]=='disk' and q[1]=='x'][0]
free=[i for i in range(P) if i!=dix]
sol,*_=np.linalg.lstsq(J2[:,free],-J2[:,dix],rcond=None)
w=np.zeros(P); w[dix]=1.0; w[free]=sol
arr=sorted([(int(p[0][-2:]),i) for i,p in enumerate(plist) if p[0].startswith("array_") and p[1]=="x"])
obs=np.array([w[arr[2*j+1][1]]/w[arr[2*j][1]] for j in range(8)])
out["max_ratio_error_vs_eta"]=float(np.abs(obs-eta).max())
np.save(artifact("null_vector_x.npy"),
        np.array([[w[arr[2*j][1]] for j in range(8)],[w[arr[2*j+1][1]] for j in range(8)]]))
print(f"  min principal cosine {out['min_principal_cosine']:.12f}")
print(f"  out/in = eta_j to {out['max_ratio_error_vs_eta']:.2e}")
print(f"  array coefficient sum {out['array_coefficient_sum']:.6f} (collimated limit {out['collimated_limit_sum']:.0f})")
json.dump(out,open(artifact("null_closed_form.json"),"w"),indent=1)
