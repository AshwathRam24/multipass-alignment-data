"""Decomposition of the degradation into model mismatch and detector noise, and a test of
which perturbed geometry parameters actually change the station-domain forward map.

Canonical convention: c_disk = 2 (mechanical tilt), consistent with every other current
artifact. The nominal and every perturbed model are built with it."""
import os, sys
from pathlib import Path
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))
os.environ.setdefault("NB", str(ROOT / "notebooks" / "amplifier_observability.ipynb"))
exec(open(HERE / "audit_setup.py").read())
import numpy as np, json
from dataclasses import replace
C_DISK = 2.0
def _seq(g):
    s = ns["build_sequence_S"](g)
    return [replace(e, c_x=C_DISK, c_y=C_DISK) if (e.kind=='tiltpoint' and e.name=='disk') else e for e in s]
J_full_c2 = ns["analytic_jacobian"](plist, _seq(G), CFG)
J_c2      = J_full_c2[:, ei]
# ---- which perturbations are actually active? ----
active={}
for f,val in [("B_m",1.05),("d1_m",1.05),("d2_m",1.05),("L_m",1.05),("a_m",1.05),
              ("q_plane_m",1.5),("W_m",1.05),("w_m",1.05)]:
    g2=replace(G,**{f:getattr(G,f)*val})
    J2=ns["analytic_jacobian"](plist,_seq(g2),CFG)
    active[f]=float(np.max(np.abs(J2-J_full_c2))/max(1e-30,np.max(np.abs(J_full_c2))))
# ---- decomposition ----
rng=np.random.default_rng(20260712); n=4000; M=12
OP={3:(2,13,1),4:None}   # filled below from exhaustive result
best=json.load(open(ROOT/"run_artifacts"/"v4_select.json"))["k4"]["operational_best"]["planes"]
pl=tuple(names.index(p) for p in best)
r=rows(pl); P=np.linalg.pinv(J_c2[r])
def run(tol_scale, noise_scale):
    """tol_scale: geometry-perturbation multiplier; noise_scale: detector-noise multiplier."""
    accs=[]
    for m in range(M):
        gg=np.random.default_rng(1000+m)
        g2=replace(G, B_m=G.B_m*(1+0.01*tol_scale*gg.standard_normal()),
                      L_m=G.L_m*(1+0.01*tol_scale*gg.standard_normal()),
                      a_m=abs(G.a_m*(1+0.01*tol_scale*gg.standard_normal())),
                      q_plane_m=abs(G.q_plane_m+0.001*tol_scale*gg.standard_normal()),
                      W_m=G.W_m*(1+0.05*tol_scale*gg.standard_normal()))
        Jt=ns["analytic_jacobian"](plist,_seq(g2),CFG)[:,ei]
        TH=gg.standard_normal((n//4,len(ei)))*ts
        Y=TH@Jt.T+gg.standard_normal((n//4,J_c2.shape[0]))*sig*noise_scale
        mu=Y[:,r]@P.T                              # inverted with the NOMINAL model
        accs.append(float(np.mean(np.all(np.abs(mu-TH)<=TOL,1))))
    return float(np.mean(accs)), float(np.std(accs))
out={"c_disk":C_DISK,"active_parameters":{k:round(v,6) for k,v in active.items()},
     "subset":best, "n_models":M, "n_per_model":n//4}
for label,(tsc,nsc) in {"reference (no perturbation, nominal noise)":(0,1),
                        "model mismatch only, moderate":(1,1),
                        "model mismatch only, severe":(3,1),
                        "detector noise only, x5":(0,5),
                        "detector noise only, x25":(0,25),
                        "combined, moderate (mismatch + x5 noise)":(1,5),
                        "combined, severe (mismatch + x25 noise)":(3,25)}.items():
    m,s=run(tsc,nsc); out[label]={"mean_acc":round(m,4),"sd_across_models":round(s,4)}
json.dump(out,open(artifact("mismatch_decomposition.json"),"w"),indent=1)
print("relative Jacobian change per perturbed parameter (+5%):")
for k,v in active.items(): print(f"   {k:11s} {v:.2e}  {'ACTIVE' if v>1e-9 else '** INERT **'}")
print("\ndecomposition (subset =",best,"):")
for k,v in out.items():
    if isinstance(v,dict) and "mean_acc" in v: print(f"   {k:45s} {v['mean_acc']:.4f} +/- {v['sd_across_models']:.4f}")
