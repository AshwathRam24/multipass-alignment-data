"""v4 corrections: (A) connector generality, (B) fixed rank criterion,
(C) mechanical-tilt units, (D) Fig.4 amplitude under the source convention."""
import os, sys
from pathlib import Path
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))
os.environ.setdefault("NB", str(ROOT / "notebooks" / "amplifier_observability.ipynb"))
exec(open(HERE / "audit_setup.py").read())
import angle_probe as _apf
from angle_probe import jacobian_pos_ang
import numpy as np, json, dataclasses, itertools
rng=np.random.default_rng(4242)
PS=lambda p: ns["prior_scale"](p)

def with_disk_c(c):
    return [dataclasses.replace(e,c_x=c,c_y=c) if (e.kind=="tiltpoint" and e.name=="disk") else e for e in seq]
def with_connectors(mats):
    out=[]; k=0
    for e in seq:
        if e.kind=="abcd" and e.name=="F_interior":
            out.append(dataclasses.replace(e,M=mats[k%len(mats)])); k+=1
        else: out.append(e)
    return out
def rank_of(J):
    s=np.linalg.svd(J,compute_uv=False)
    return int((s>s[0]*max(J.shape)*np.finfo(float).eps).sum())

res={}
# ---------- (A) is F^4 = I necessary? ----------
print("=== (A) connector generality ===")
Jn=ns["analytic_jacobian"](plist,seq,CFG); print(f"  Fourier connector      : rank {rank_of(Jn)} of {len(plist)}")
gen=[]
B0=19.063
def Mrot(alpha_deg, B=B0):
    a=np.radians(alpha_deg)
    return np.array([[np.cos(a), B*np.sin(a)],[-np.sin(a)/B, np.cos(a)]])
# generalised-Fourier connectors: symplectic, beam-stable, NOT Fourier unless alpha = 90 deg.
# alpha = 90 gives F with F^4 = I; other angles give M^4 != I and, for irrational ratios,
# no periodicity at all over the eight passes.
for alpha,Bv in [(90,B0),(75,B0),(60,B0),(50,B0),(45,B0),(120,B0),(135,B0),
                 (90,0.5*B0),(63.7,1.7*B0),(112.3,0.6*B0)]:
    M=Mrot(alpha,Bv)
    try: Jg=ns["analytic_jacobian"](plist,with_connectors([M]),CFG)
    except Exception as ex:
        print(f"  alpha={alpha:6.1f} B={Bv:7.3f}: beam not self-consistent, skipped"); continue
    M4=np.linalg.matrix_power(M,4); per4=bool(np.allclose(M4,np.eye(2),atol=1e-9))
    gen.append({"alpha_deg":alpha,"B":Bv,"det":float(np.linalg.det(M)),
                "M4_is_identity":per4,"rank":rank_of(Jg)})
    print(f"  alpha={alpha:6.1f} B={Bv:7.3f}: rank {gen[-1]['rank']:2d}   M^4 = I? {str(per4):5s}")
# degenerate case: B = 0 (imaging connector) -- prediction: the local argument fails
M0=np.array([[1.0,0.0],[0.0,1.0]]); J0=ns["analytic_jacobian"](plist,with_connectors([M0]),CFG)
Mi=np.array([[-1.0,0.0],[0.0,-1.0]]); Ji=ns["analytic_jacobian"](plist,with_connectors([Mi]),CFG)
print(f"  identity connector (B=0): rank {rank_of(J0)}")
print(f"  -I connector      (B=0): rank {rank_of(Ji)}")
res["connector_generality"]={"fourier_rank":rank_of(Jn),"generic":gen,
    "identity_B0_rank":rank_of(J0),"minus_identity_B0_rank":rank_of(Ji),"n_params":len(plist)}

# ---------- (B) rank criterion, done properly ----------
print("\n=== (B) structural criterion by augmented rank ===")
_apf.ns=ns; _apf.np=np
Jp,Ja,snames=jacobian_pos_ang(plist,seq,CFG)
Jw=(Jp/sig[:,None])*np.array([PS(p[0]) for p in plist])[None,:]
r0=rank_of(Jw); U,S,Vt=np.linalg.svd(Jw); N=Vt[r0:].T
cls=lambda n:("incoming array" if n.startswith("array_") and int(n[-2:])%2 else
              "outgoing array" if n.startswith("array_") else
              "M2 leak-through" if n.startswith("Q") else "output")
tab={}
for p,n in enumerate(snames):
    Aw=(Ja[2*p:2*p+2]/ (5e-6/4.0))*np.array([PS(q[0]) for q in plist])[None,:]
    dr=rank_of(np.vstack([Jw,Aw]))-r0
    rel=float(np.linalg.norm(Aw@N)/max(np.linalg.norm(Aw),1e-300))
    tab.setdefault(cls(n),[]).append({"plane":n,"rank_gain":dr,"rel_norm":rel})
for k,v in tab.items():
    print(f"  {k:16s} n={len(v):2d}  rank gain {sorted({x['rank_gain'] for x in v})}  "
          f"rel norm [{min(x['rel_norm'] for x in v):.2e}, {max(x['rel_norm'] for x in v):.2e}]")
res["rank_criterion"]={"base_rank":r0,"by_class":tab}
json.dump(res,open(artifact("v4_generality.json"),"w"),indent=1)
