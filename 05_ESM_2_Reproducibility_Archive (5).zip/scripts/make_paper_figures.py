#!/usr/bin/env python3
"""Regenerate figures 1-5 of the manuscript from archived artifacts.

Usage:  python3 scripts/make_paper_figures.py [--out figures]

Inputs (relative to the archive root):
    data/digitized_schuhmann_fig4.csv          -> figure 1
    run_artifacts/structure_c2.json            -> figure 2(a)  [c_disk = 2 canonical]
    run_artifacts/null_closed_form.json        -> figure 2(b)
    run_artifacts/rank_criterion.json          -> figure 3(a)
    run_artifacts/v5_reliability.json          -> figure 3(b)
    run_artifacts/v4_generality.json           -> figure 2(c)
    run_artifacts/v4_select.json               -> figure 4
    run_artifacts/mismatch_decomposition.json  -> figure 5

Fonts are embedded as Type 42 (TrueType), as required by most publishers.
"""
import argparse, csv, json, os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

plt.rcParams.update({"pdf.fonttype": 42, "ps.fonttype": 42, "font.size": 9,
                     "font.family": "serif", "axes.linewidth": 0.7})

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
J = lambda *p: os.path.join(ROOT, *p)


def load(p):
    with open(J(*p)) as f:
        return json.load(f)


def save(fig, out, n):
    fig.savefig(os.path.join(out, f"figure{n}.pdf"), bbox_inches="tight")
    fig.savefig(os.path.join(out, f"figure{n}.png"), dpi=300, bbox_inches="tight")
    fig.savefig(os.path.join(out, f"Fig{n}.eps"), format="eps", bbox_inches="tight")
    plt.close(fig)
    print(f"  figure{n}: written")


# ---------------------------------------------------------------- figure 1
def figure1(out):
    """Station-domain validation against figure 4 of Ref. [7].

    The model curve is computed here, not read from a stored result. The adopted
    convention is c_disk = 2 (source: theta = 2 phi), under which the published blue
    curve corresponds to a 25 urad MECHANICAL disk tilt rather than the 50 urad of its
    caption -- see Sect. 2.3. The printed metrics must reproduce 0.0961/0.9982 and
    0.0831/0.9982.
    """
    import audit_setup                                    # loads the archived model
    ns = audit_setup.ns
    rows = list(csv.DictReader(open(J("data", "digitized_schuhmann_fig4.csv"))))
    get = lambda c: np.array([[float(r["z_source"]), float(r["excursion_m"])]
                              for r in rows if r["curve"] == c])
    lm = np.sort(get("landmark_disk")[:, 0])              # the eight disk stations
    fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.7), gridspec_kw=dict(wspace=0.28))
    for a, curve, ttl, kw, loc in (
            (ax[0], "disk50",   "(a) disk tilt, 25 µrad mechanical", dict(theta_disk=25e-6),   (0.03, 0.96, "top")),
            (ax[1], "input100", "(b) input angle, 100 µrad",         dict(theta_input=100e-6), (0.03, 0.30, "top"))):
        d = get(curve); o = np.argsort(d[:, 0])
        model = np.asarray(ns["ideal_station_model"](c_disk=2.0, **kw)).ravel()[0::2]
        dig = np.interp(lm, d[o, 0], d[o, 1])
        nrmse = np.sqrt(np.mean((model - dig) ** 2)) / np.max(np.abs(dig))
        r = np.corrcoef(model, dig)[0, 1]
        print(f"    {curve}: NRMSE {nrmse:.4f}  r {r:.4f}")
        a.plot(d[o, 0], d[o, 1] * 1e6, color="0.55", lw=1.0, label="digitized [7]")
        a.plot(lm, model * 1e6, "o", color="C3", ms=4.5, mfc="none", mew=1.2,
               label="model, disk stations")
        a.set_title(ttl, fontsize=8.5)
        a.set_xlabel("position along beam path (published units)", fontsize=7.5)
        a.text(loc[0], loc[1], f"NRMSE {nrmse:.4f}\n$r$ = {r:.4f}",
               transform=a.transAxes, va=loc[2], fontsize=6.8)
        a.legend(fontsize=6.3, frameon=False,
                 loc="lower right" if curve == "disk50" else "upper right")
    ax[0].set_ylabel("beam-axis excursion (µm)")
    save(fig, out, 1)


# ---------------------------------------------------------------- figure 2
def figure2(out):
    """Spectrum, the exact closed form, and connector generality."""
    sv = np.array(load(("run_artifacts", "structure_c2.json"))["singvals"])
    cf = load(("run_artifacts", "null_closed_form.json"))
    gg = load(("run_artifacts", "v4_generality.json"))["connector_generality"]
    fig, ax = plt.subplots(1, 3, figsize=(7.4, 2.7), gridspec_kw=dict(wspace=0.44))
    a = ax[0]
    a.semilogy(range(1, len(sv) + 1), sv / sv[0], "ko-", ms=2.4, lw=0.7)
    a.axvspan(36.5, 38.5, color="C3", alpha=0.15)
    a.annotate("blind\nsubspace", xy=(37.3, 3e-16), xytext=(24, 1e-11), fontsize=6.2,
               color="C3", arrowprops=dict(arrowstyle="->", color="C3", lw=0.6))
    a.set_xlabel("singular-value index", fontsize=7.5)
    a.set_ylabel(r"$\sigma_k/\sigma_1$", fontsize=8)
    a.set_title("(a) spectrum, 20 position planes", fontsize=8)
    a.tick_params(labelsize=6.5)

    b = ax[1]
    x = np.arange(8)
    b.plot(x, cf["phi_in_per_pass"], "o-", color="C0", ms=4, lw=1.0, label="incoming, Eq. (3)")
    b.plot(x, cf["phi_out_per_pass"], "s-", color="C1", ms=4, lw=1.0, label="outgoing, Eq. (3)")
    w = np.load(J("run_artifacts", "null_vector_x.npy"))
    b.plot(x, w[0], "kx", ms=4, mew=1.0, label="numerical null vector")
    b.plot(x, w[1], "kx", ms=4, mew=1.0)
    b.set_xticks(x)
    b.set_xticklabels([f"{i+1}\n{c}" for i, c in enumerate(cf["connector_before_pass"])], fontsize=6)
    b.set_xlabel("disk pass / preceding connector", fontsize=7.5)
    b.set_ylabel("array coefficient (disk = 1)", fontsize=7.5)
    b.set_title("(b) blind direction, exactly", fontsize=8)
    b.tick_params(axis="y", labelsize=6.5)
    b.set_ylim(-0.5215, -0.4785)
    b.legend(fontsize=5.6, frameon=False, loc="center", bbox_to_anchor=(0.5, 0.5))

    c = ax[2]
    P = gg["n_params"]
    lbl, val, col = [], [], []
    lbl.append("Fourier\n$M^4\!=\!I$"); val.append(gg["fourier_rank"]); col.append("C2")
    npr = [g for g in gg["generic"] if not g["M4_is_identity"]]
    lbl.append(f"generalized\nFourier ($\\times${len(npr)})"); val.append(npr[0]["rank"]); col.append("C0")
    lbl.append("relay\n$M=\\pm I$"); val.append(gg["identity_B0_rank"]); col.append("C3")
    c.bar(range(3), [P - v for v in val], color=col, edgecolor="k", lw=0.5)
    c.set_xticks(range(3)); c.set_xticklabels(lbl, fontsize=6)
    c.set_ylabel("nullity (of %d)" % P, fontsize=7.5)
    c.set_title("(c) connector generality", fontsize=8)
    c.tick_params(axis="y", labelsize=6.5)
    for i, v in enumerate(val):
        c.text(i, P - v + 0.25, f"{P-v}", ha="center", fontsize=7)
    c.set_ylim(0, 12)
    save(fig, out, 2)


# ---------------------------------------------------------------- figure 3
def figure3(out):
    """Structural criterion, and precision-optimal far-field placement."""
    rc = load(("run_artifacts", "rank_criterion.json"))["by_class"]
    fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.9), gridspec_kw=dict(wspace=0.36))
    a = ax[0]
    order = ["incoming array", "outgoing array", "M2 leak-through", "output"]
    xs, ys, cs, lbl, i = [], [], [], [], 0
    for k in order:
        for e in rc[k]:
            xs.append(i); ys.append(max(e["rel_norm"], 1e-17))
            cs.append("C2" if e["rank_gain"] == 2 else "0.65"); i += 1
        lbl.append((i - len(rc[k]) / 2 - 0.5, k))
    a.bar(xs, ys, color=cs, edgecolor="k", lw=0.3)
    a.set_yscale("log"); a.set_ylim(1e-17, 3.0)
    a.set_ylabel(r"$\|A_pN\|\,/\,\|A_p\|$", fontsize=8)
    a.set_xticks([p for p, _ in lbl])
    a.set_xticklabels([n.replace(" ", "\n") for _, n in lbl], fontsize=6.2)
    a.set_title(r"(a) structural criterion: rank$(A_pN)=2$", fontsize=8.5)
    a.set_ylim(1e-17, 40.0)
    a.text(0.03, 0.95, "rank gain 2", color="C2", fontsize=6.6, va="top", transform=a.transAxes)
    a.text(0.98, 0.36, "rank gain 0\n(machine zero)", color="0.35", fontsize=6.6,
           ha="right", transform=a.transAxes)

    b = ax[1]
    rl = load(("run_artifacts", "v5_reliability.json"))
    ks = [k for k in range(1, 11)]
    sig_ = [rl[str(k)]["sigma_x_urad"] for k in ks]
    p1 = [rl[str(k)]["P_one_axis"] for k in ks]
    p2 = [rl[str(k)]["P_two_axis"] for k in ks]
    tol = rl["tolerance_urad"]
    b.plot(ks, sig_, "o-", color="C2", ms=4.5, lw=1.2, label=r"$\sigma_\varphi$ (CRLB)")
    b.axhline(tol, color="C3", lw=1.0)
    b.text(5.4, tol * 1.05, "tolerance scale", fontsize=6.0, color="C3")
    b.set_xticks(ks); b.set_xlabel("optimally placed far-field channels", fontsize=7.5)
    b.set_ylabel(r"$\sigma_\varphi$ (µrad)", fontsize=8, color="C2")
    b.tick_params(axis="y", colors="C2", labelsize=6.5)
    b.tick_params(axis="x", labelsize=6.5)
    b2 = b.twinx()
    b2.plot(ks, p1, "s--", color="C0", ms=3.8, lw=1.0, label="P, one axis")
    b2.plot(ks, p2, "^:", color="C4", ms=3.8, lw=1.0, label="P, two-axis magnitude")
    b2.plot(ks, [rl[str(k)]["P_one_axis_mc"] for k in ks], "k.", ms=3, label="WLS Monte Carlo")
    b2.plot(ks, [rl[str(k)]["P_two_axis_mc"] for k in ks], "k.", ms=3)
    b2.axhline(0.90, color="0.5", lw=0.7, ls="-.")
    b2.text(1.05, 0.915, "90 %", fontsize=6.0, color="0.35")
    b2.set_ylim(0, 1.05); b2.set_ylabel("P(within tolerance)", fontsize=8)
    b2.tick_params(axis="y", labelsize=6.5)
    h1, l1 = b.get_legend_handles_labels(); h2, l2 = b2.get_legend_handles_labels()
    b2.legend(h1 + h2, l1 + l2, fontsize=5.8, frameon=False, loc="center right")
    b.set_title("(b) precision is not reliability", fontsize=8.5)
    save(fig, out, 3)


# ---------------------------------------------------------------- figure 4
def figure4(out):
    """Detector placement for the reduced six-parameter problem."""
    d = load(("run_artifacts", "v4_select.json"))
    ks = [3, 4, 5, 6]
    sel = [d[f"k{k}"]["operational_best"]["acc_select"] for k in ks]
    ver = [d[f"k{k}"]["operational_best"]["acc_verify"] for k in ks]
    bay = [d[f"k{k}"]["operational_best"]["acc_bayes_verify"] for k in ks]
    eo = [d[f"k{k}"]["E_optimal"]["acc_verify"] for k in ks]
    do = [d[f"k{k}"]["D_optimal"]["acc_verify"] for k in ks]
    crlb = [d[f"k{k}"]["operational_best"]["crlb_max_urad"] for k in ks]
    fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.9), gridspec_kw=dict(wspace=0.34))
    a = ax[0]
    a.plot(ks, ver, "o-", color="C2", ms=6, lw=1.3, label="exhaustive optimum")
    a.plot(ks, eo, "P--", color="C4", ms=5, lw=1.1, label="E-optimal (true)")
    a.plot(ks, bay, "s:", color="C0", ms=4, lw=0.9, label="optimum, prior-aware")
    a.plot(ks, do, "^-", color="C1", ms=4.5, label="D-optimal")
    a.plot(ks, sel, "k.", ms=4, label="selection score")
    a.set_xticks(ks); a.set_ylim(0, 1)
    a.set_xlabel("number of instrumented planes"); a.set_ylabel("recovery probability")
    a.set_title("(a) selection criteria (verification draws)", fontsize=8.5)
    a.legend(fontsize=6.0, frameon=False, loc="lower right")

    b = ax[1]
    b.bar([k - 0.16 for k in ks], ver, width=0.32, color="C2", edgecolor="k", lw=0.4)
    b.set_xticks(ks); b.set_ylim(0, 1)
    b.set_xlabel("number of instrumented planes"); b.set_ylabel("recovery probability")
    b2 = b.twinx()
    b2.plot([k + 0.16 for k in ks], crlb, "D-", color="C3", ms=4, lw=1.0)
    b2.set_ylabel("worst-parameter bound (µrad)", color="C3")
    b2.tick_params(axis="y", colors="C3")
    b.set_title("(b) best subset: recovery and bound", fontsize=8.5)
    save(fig, out, 4)


# ---------------------------------------------------------------- figure 5
def figure5(out):
    """Degradation decomposed into geometry perturbation and detector noise."""
    m = load(("run_artifacts", "mismatch_decomposition.json"))
    keys = [("model mismatch only, moderate", "geometry\n1 %"),
            ("model mismatch only, severe", "geometry\n3 %"),
            ("detector noise only, x5", "noise\n$\\times$5"),
            ("detector noise only, x25", "noise\n$\\times$25"),
            ("combined, moderate (mismatch + x5 noise)", "both\nmoderate"),
            ("combined, severe (mismatch + x25 noise)", "both\nsevere")]
    ref = m["reference (no perturbation, nominal noise)"]["mean_acc"]
    y = [m[k]["mean_acc"] for k, _ in keys]
    e = [m[k]["sd_across_models"] for k, _ in keys]
    cols = ["C0", "C0", "C1", "C1", "0.45", "0.45"]
    fig, ax = plt.subplots(figsize=(4.6, 2.9))
    ax.bar(range(len(y)), y, yerr=e, color=cols, edgecolor="k", lw=0.5,
           capsize=3, error_kw=dict(lw=0.8))
    ax.axhline(ref, ls=":", color="k", lw=0.9)
    ax.text(len(y) - 0.6, ref + 0.02, f"unperturbed, {ref:.3f}", fontsize=6.3, ha="right")
    ax.set_xticks(range(len(y)))
    ax.set_xticklabels([lab for _, lab in keys], fontsize=6.5)
    ax.set_ylim(0, 1)
    ax.set_ylabel("recovery probability")
    save(fig, out, 5)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="figures")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    print(f"regenerating manuscript figures into {a.out}/")
    for fn in (figure1, figure2, figure3, figure4, figure5):
        fn(a.out)
    print("done.")
