"""v4 selection: mechanical-tilt convention, true E-optimality, and an INDEPENDENT
verification pass (winner frozen on the selection draws, re-scored on fresh draws)."""
import os, sys
from pathlib import Path
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))
os.environ.setdefault("NB", str(ROOT / "notebooks" / "amplifier_observability.ipynb"))
exec(open(HERE / "audit_setup.py").read())
import angle_probe as _apf
from angle_probe import jacobian_pos_ang
import numpy as np, itertools, json, time, dataclasses
seq2=[dataclasses.replace(e,c_x=2.0,c_y=2.0) if (e.kind=="tiltpoint" and e.name=="disk") else e for e in seq]
J2=ns["analytic_jacobian"](plist,seq2,CFG)
ei2=[i for i,p in enumerate(plist) if p[0] in ("input","disk","M2")]
Jr=J2[:,ei2]; ts2=np.array([ns["prior_scale"](plist[i][0]) for i in ei2])
rng=np.random.default_rng(20260712); n=4000
TH=rng.standard_normal((n,len(ei2)))*ts2
Y=TH@Jr.T+rng.standard_normal((n,Jr.shape[0]))*sig
vr=np.random.default_rng(99001); nv=100000                      # independent verification draws
THv=vr.standard_normal((nv,len(ei2)))*ts2
Yv=THv@Jr.T+vr.standard_normal((nv,Jr.shape[0]))*sig
Jw=(Jr/sig[:,None])*ts2[None,:]
ld  =lambda pl: float(np.sum(np.log(np.linalg.svd(Jw[rows(pl)],compute_uv=False)**2+1e-30)))
smin=lambda pl: float(np.linalg.svd(Jw[rows(pl)],compute_uv=False)[-1])
def crlb_max(pl):
    Js=Jr[rows(pl)]/sig[rows(pl)][:,None]; s=np.linalg.svd(Js,compute_uv=False)
    if s[-1]<=s[0]*1e-12: return None
    return float(np.max(np.sqrt(np.diag(np.linalg.inv(Js.T@Js))))*1e6)
def acc(pl,TH_,Y_,bayes=False):
    r=rows(pl); Js=Jr[r]
    if bayes:
        Jn=Js/sig[r][:,None]; A=np.linalg.inv(Jn.T@Jn+np.diag(1/ts2**2)); mu=(Y_[:,r]/sig[r])@(A@Jn.T).T
    else: mu=Y_[:,r]@np.linalg.pinv(Js).T
    return float(np.mean(np.all(np.abs(mu-TH_)<=TOL,1)))
out={"convention":"c_disk = 2 (mechanical tilt)","n_select":n,"n_verify":nv,"tol_urad":round(TOL*1e6,3)}
for k in (3,4,5,6):
    t0=time.time(); res=[]
    for c in itertools.combinations(range(len(names)),k):
        if np.linalg.matrix_rank(Jr[rows(c)])<len(ei2): continue
        res.append((acc(c,TH,Y),c))
    res.sort(reverse=True); rank={c:i+1 for i,(a,c) in enumerate(res)}
    allc=list(itertools.combinations(range(len(names)),k))
    dbest=max(allc,key=ld); ebest=max(allc,key=smin)
    blk=lambda c:{"planes":[names[i] for i in c],"acc_select":round(acc(c,TH,Y),4),
                  "acc_verify":round(acc(c,THv,Yv),4),"operational_rank":rank.get(c),
                  "crlb_max_urad":None if crlb_max(c) is None else round(crlb_max(c),3)}
    b=res[0][1]
    out[f"k{k}"]={"n_identifiable":len(res),"n_total":len(allc),
      "operational_best":dict(blk(b),acc_bayes_select=round(acc(b,TH,Y,True),4),
                              acc_bayes_verify=round(acc(b,THv,Yv,True),4)),
      "E_optimal":blk(ebest),"D_optimal":blk(dbest)}
    x=out[f"k{k}"]; o=x["operational_best"]
    print(f"k={k}: best {o['planes']} select {o['acc_select']} verify {o['acc_verify']} "
          f"(bayes {o['acc_bayes_verify']}) CRLB {o['crlb_max_urad']}")
    print(f"      E-opt rank {x['E_optimal']['operational_rank']:>5} verify {x['E_optimal']['acc_verify']}"
          f" | D-opt rank {x['D_optimal']['operational_rank']:>5} verify {x['D_optimal']['acc_verify']}",flush=True)
json.dump(out,open(artifact("v4_select.json"),"w"),indent=1)
