"""Shared setup for the correction analyses: loads the archived station model."""
import numpy as np, json, re, nbformat, itertools, os, sys
from pathlib import Path
_ROOT = Path(__file__).resolve().parent.parent
ARCHIVE_ROOT = _ROOT
DATA_CSV = str(_ROOT / "data" / "digitized_schuhmann_fig4.csv")
ARTIFACTS = _ROOT / "run_artifacts"
def load():
    ns={}; nb=nbformat.read(os.environ.get("NB", str(_ROOT/"notebooks"/"amplifier_observability.ipynb")),as_version=4)
    for i,c in enumerate(nb.cells):
        if c.cell_type!="code": continue
        s=c.source.replace("\ntest_v05()","\n_=0").replace("\ntest_v04()","\n_=0")
        if re.search(r"^(author_gate\(\)|E0\(\)|full_run\(|smoke_all\(|record_status\()",s,re.M): continue
        try: exec(compile(s,f"<c{i}>","exec"),ns)
        except (ModuleNotFoundError,AssertionError): continue
    return ns
ns=load()
G=ns["StationGeom"](); seq=ns["build_sequence_S"](G); CFG=ns["CFG"]
plist=ns["param_names"](seq); names=ns["sensor_names"](seq)
J_full=ns["analytic_jacobian"](plist,seq,CFG)
nz0,_=ns["REGIMES"]["nominal"]
sig=ns["sigma_channels"](seq,nz0)                      # per-channel sd, diagonal
ei=[i for i,p in enumerate(plist) if p[0] in ("input","disk","M2")]
J=J_full[:,ei]; ts=np.array([ns["prior_scale"](plist[i][0]) for i in ei])
TOL=ns["phi_tol"](0.01,1.07e8)
rows=lambda pl: sorted(i for p in pl for i in (2*p,2*p+1))

def artifact(name):
    """Absolute path for an output artifact, independent of the working directory."""
    ARTIFACTS.mkdir(exist_ok=True)
    return str(ARTIFACTS / name)
