"""Structural vs precision-optimal far-field placement.
(1) rank(A_p N): which planes' angle rows interrogate the position-null subspace.
(2) exhaustive optimisation of the disk-tilt CRLB over angle-channel subsets, ALL planes."""
import os, sys
from pathlib import Path
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))
os.environ.setdefault("NB", str(ROOT / "notebooks" / "amplifier_observability.ipynb"))
exec(open(HERE / "audit_setup.py").read())
from angle_probe import jacobian_pos_ang
import numpy as np, itertools, json, time
import dataclasses
C_DISK=2.0   # source-consistent: theta = 2 phi (Sect. 2.3)
seq2=[dataclasses.replace(e,c_x=C_DISK,c_y=C_DISK) if (e.kind=="tiltpoint" and e.name=="disk") else e for e in seq]
Jp,Ja,snames=jacobian_pos_ang(plist,seq2,CFG); P=len(plist)
di=[i for i,q in enumerate(plist) if q[0]=="disk"]
ps=np.array([ns["prior_scale"](p[0]) for p in plist])
Jw=(Jp/sig[:,None])*ps[None,:]
U,S,Vt=np.linalg.svd(Jw); N=Vt[-2:].T                     # 38 x 2 null basis
cls=lambda n:("incoming array" if n.startswith("array_") and int(n[-2:])%2==1 else
              "outgoing array" if n.startswith("array_") else
              "M2 leak-through" if n.startswith("Q") else "output")
print("=== (1) structural criterion, by AUGMENTED RANK ===")
# NOTE: rank(A_p N) must NOT be tested against the norm of A_p N itself -- for the
# planes that carry no null-space response that norm is ~1e-19 and its own relative
# tolerance admits pure numerical noise. The rank GAIN of the augmented design is the
# well-posed quantity and is what the manuscript reports.
def _rank(M):
    s=np.linalg.svd(M,compute_uv=False)
    return int((s>s[0]*max(M.shape)*np.finfo(float).eps).sum())
ps_all=np.array([ns["prior_scale"](p[0]) for p in plist])
Jw=(Jp/sig[:,None])*ps_all[None,:]
r0=_rank(Jw); U,S,Vt=np.linalg.svd(Jw); N=Vt[r0:].T
sa_ref=5e-6/4.0
tab={}
for p,n in enumerate(snames):
    Aw=(Ja[2*p:2*p+2]/sa_ref)*ps_all[None,:]
    tab.setdefault(cls(n),[]).append({
        "plane":n,
        "rank_gain":_rank(np.vstack([Jw,Aw]))-r0,
        "norm":float(np.linalg.norm(Aw@N)),
        "rel_norm":float(np.linalg.norm(Aw@N)/max(np.linalg.norm(Aw),1e-300))})
for k,v in tab.items():
    print(f"  {k:16s} n={len(v):2d}  rank gain {sorted({x['rank_gain'] for x in v})}   "
          f"rel norm [{min(x['rel_norm'] for x in v):.2e}, {max(x['rel_norm'] for x in v):.2e}]")
json.dump({"base_rank":r0,"n_params":len(plist),"by_class":tab},
          open(artifact("rank_criterion.json"),"w"),indent=1)

print("\n=== (2) exhaustive far-field subset optimisation (f = 4 m, sigma_cam = 5 um) ===",flush=True)
sa=5e-6/4.0
def disk_bound(pl):
    r=[Jp]; s=[sig]
    for p in pl: r.append(Ja[2*p:2*p+2]); s.append(np.full(2,sa))
    Js=np.vstack(r)/np.concatenate(s)[:,None]
    sv=np.linalg.svd(Js,compute_uv=False)
    if sv[-1]<=sv[0]*1e-10: return None
    return float(np.sqrt(np.diag(np.linalg.inv(Js.T@Js)))[di].max()*1e6)
res={}
for k in range(1,9):
    t0=time.time(); best=(1e18,None); nid=0
    for c in itertools.combinations(range(len(snames)),k):
        d=disk_bound(c)
        if d is None: continue
        nid+=1
        if d<best[0]: best=(d,c)
    res[k]={"best_bound_urad":round(best[0],3),"planes":[snames[i] for i in best[1]],
            "n_identifiable":nid,"n_total":len(list(itertools.combinations(range(len(snames)),k)))}
    print(f"  k={k}: best disk CRLB {best[0]:8.3f} urad   {[snames[i] for i in best[1]]}   ({nid} identifiable, {time.time()-t0:.0f}s)",flush=True)
    json.dump({"tolerance_urad":round(TOL*1e6,3),"f_focal_m":4.0,"sigma_cam_m":5e-6,"by_k":res},
              open(artifact("farfield_opt.json"),"w"),indent=1)
