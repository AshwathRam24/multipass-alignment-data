"""Canonical structural artifact under the adopted convention c_disk = 2.

Computes the noise-whitened, prior-scaled measurement Jacobian with all twenty position
planes instrumented, its rank, its full singular spectrum and the set of parameters with
null-space support. Writes run_artifacts/structure_c2.json, which backs Sect. 3.2 and
Fig. 2(a) of the article."""
import os, sys
from pathlib import Path
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))
os.environ.setdefault("NB", str(ROOT / "notebooks" / "amplifier_observability.ipynb"))
exec(open(HERE / "audit_setup.py").read())
import numpy as np, json, dataclasses
C_DISK = 2.0
seq2=[dataclasses.replace(e,c_x=C_DISK,c_y=C_DISK) if (e.kind=="tiltpoint" and e.name=="disk") else e for e in seq]
J2=ns["analytic_jacobian"](plist,seq2,CFG)
ps=np.array([ns["prior_scale"](p[0]) for p in plist])
Jw=(J2/sig[:,None])*ps[None,:]
s=np.linalg.svd(Jw,compute_uv=False)
rank=int((s>s[0]*max(Jw.shape)*np.finfo(float).eps).sum())
U,S,Vt=np.linalg.svd(Jw); N=Vt[rank:].T
sup=[plist[i] for i in range(len(plist)) if np.linalg.norm(N[i])>1e-8]
out={"c_disk":C_DISK,"shape":list(Jw.shape),"rank":rank,"nullity":len(plist)-rank,
     "singvals":s.tolist(),"singvals_normalised":(s/s[0]).tolist(),
     "sigma36_over_sigma1":float(s[35]/s[0]),"sigma37_over_sigma1":float(s[36]/s[0]),
     "sigma38_over_sigma1":float(s[37]/s[0]),
     "n_params_with_null_support":len(sup),
     "params_with_null_support":[list(p) for p in sup],
     "note":"noise-whitened, prior-scaled Jacobian; c_disk = 2 (mechanical tilt)"}
print(f"shape {Jw.shape}  rank {rank}  nullity {len(plist)-rank}")
print(f"  sigma36/sigma1 = {s[35]/s[0]:.4e}")
print(f"  sigma37/sigma1 = {s[36]/s[0]:.3e}   sigma38/sigma1 = {s[37]/s[0]:.3e}")
print(f"  parameters with null-space support: {len(sup)} of {len(plist)}")
json.dump(out,open(artifact("structure_c2.json"),"w"),indent=1)
