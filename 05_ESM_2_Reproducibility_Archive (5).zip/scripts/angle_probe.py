"""Does an angle-sensitive (far-field) measurement break the beam-position blind subspace?
Builds the angle rows of the station-domain Jacobian and tests rank restoration."""
import os, sys
from pathlib import Path
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))
os.environ.setdefault("NB", str(ROOT / "notebooks" / "amplifier_observability.ipynb"))
exec(open(HERE / "audit_setup.py").read())
import numpy as np, itertools, json

def jacobian_pos_ang(plist, seq, cfg):
    """Return (J_pos, J_ang): position and ANGLE sensitivity at every sensor plane."""
    chain = ns["aligned_beam_chain"](seq, cfg); wR_ap,_ = chain
    snames=[el.name for el in seq if el.kind=='sensor']
    Jp=np.zeros((2*len(snames),len(plist))); Ja=np.zeros((2*len(snames),len(plist)))
    col={p:j for j,p in enumerate(plist)}
    for axis_index,axis in enumerate(('x','y')):
        active=[]; k_ap=0; s_i=0
        for el in seq:
            if el.kind=='prop':    M=ns["M_prop"](el.value);  active=[(j,M@v) for j,v in active]
            elif el.kind=='focus': M=ns["M_focus"](el.value); active=[(j,M@v) for j,v in active]
            elif el.kind=='abcd':  active=[(j,el.M@v) for j,v in active]
            elif el.kind=='flip_y':
                if axis=='y': active=[(j,-v) for j,v in active]
            elif el.kind=='aperture':
                w_in,R=wR_ap[k_ap]; M=ns["M_aperture_geom"](w_in,el.W_m,R)
                active=[(j,M@v) for j,v in active]; k_ap+=1
            elif el.kind=='tiltpoint':
                p=(el.name,axis)
                if p in col: active.append((col[p],np.array([0.0, el.c_x if axis=='x' else el.c_y])))
            elif el.kind=='sensor':
                for j,v in active: Jp[2*s_i+axis_index,j]+=v[0]; Ja[2*s_i+axis_index,j]+=v[1]
                s_i+=1
    return Jp,Ja,snames

if __name__ == "__main__":
    Jp,Ja,snames=jacobian_pos_ang(plist,seq,CFG)
    r=lambda M: int(np.linalg.matrix_rank(M, tol=np.linalg.svd(M,compute_uv=False)[0]*1e-10))
    print(f"position-only Jacobian: {Jp.shape} rank {r(Jp)}  (nullity {Jp.shape[1]-r(Jp)})")
    print(f"angle-only   Jacobian: {Ja.shape} rank {r(Ja)}")
    print(f"position+angle, all planes: rank {r(np.vstack([Jp,Ja]))}")
    # minimal angle additions
    out={"rank_position_only":r(Jp),"n_params":Jp.shape[1]}
    single=[]
    for p in range(len(snames)):
        aug=np.vstack([Jp, Ja[2*p:2*p+2]])
        single.append((r(aug), snames[p]))
    best=max(single)
    out["single_angle_plane"]={"best_rank":best[0],"planes_reaching_full":[n for rk,n in single if rk==Jp.shape[1]],
                               "rank_by_plane":{n:rk for rk,n in single}}
    print(f"\nadding the angle pair at ONE plane -> best rank {best[0]}")
    full=[n for rk,n in single if rk==38]
    print(f"   planes that restore full rank 38: {len(full)} of {len(snames)}")
    print(f"   {full if full else '(none)'}")
    json.dump(out,open(artifact("angle_probe.json"),"w"),indent=1,default=str)

