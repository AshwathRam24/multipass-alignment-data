"""Operational reliability, not just a precision scale.

A Cramer-Rao sigma below the tolerance does NOT mean the estimate stays inside it.
We report, for each far-field channel count:
  (i)   sigma_phi, the Cramer-Rao bound on the mechanical disk tilt;
  (ii)  the Gaussian efficient-estimator reliability BENCHMARK -- the probability of
        landing within tolerance for a zero-mean Gaussian error with that covariance,
        per axis and for the two-axis tilt magnitude. This is a benchmark computed
        under the assumed linear-Gaussian measurement model, not a universal bound;
  (iii) a direct weighted-least-squares Monte Carlo under the same model, which is the
        efficient estimator here, as a check that the benchmark is attained."""
import os, sys
from pathlib import Path
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))
os.environ.setdefault("NB", str(ROOT / "notebooks" / "amplifier_observability.ipynb"))
exec(open(HERE / "audit_setup.py").read())
import angle_probe as _apf
from angle_probe import jacobian_pos_ang
import numpy as np, json, itertools, dataclasses
from math import erf, sqrt, exp
_apf.ns=ns; _apf.np=np
seq2=[dataclasses.replace(e,c_x=2.0,c_y=2.0) if (e.kind=="tiltpoint" and e.name=="disk") else e for e in seq]
Jp,Ja,snames=jacobian_pos_ang(plist,seq2,CFG)
dx=[i for i,q in enumerate(plist) if q[0]=="disk" and q[1]=="x"][0]
dy=[i for i,q in enumerate(plist) if q[0]=="disk" and q[1]=="y"][0]
T=TOL*1e6
def cov(pl,f=4.0,sc=5e-6):
    sa=sc/f; r=[Jp]; s=[sig]
    for p in pl: r.append(Ja[2*p:2*p+2]); s.append(np.full(2,sa))
    Js=np.vstack(r)/np.concatenate(s)[:,None]
    sv=np.linalg.svd(Js,compute_uv=False)
    if sv[-1]<=sv[0]*1e-10: return None
    return np.linalg.inv(Js.T@Js)
N_MC = 200000
def wls_mc(pl, f=4.0, sc=5e-6):
    """Direct Monte Carlo with the weighted least-squares (efficient) estimator."""
    sa=sc/f; r=[Jp]; s=[sig]
    for p in pl: r.append(Ja[2*p:2*p+2]); s.append(np.full(2,sa))
    Jm=np.vstack(r); sd=np.concatenate(s)
    Js=Jm/sd[:,None]
    if np.linalg.svd(Js,compute_uv=False)[-1]<=np.linalg.svd(Js,compute_uv=False)[0]*1e-10: return None,None
    Pinv=np.linalg.solve(Js.T@Js, Js.T)                     # WLS estimator matrix
    g=np.random.default_rng(31337)
    th=np.zeros(len(plist))                                  # truth at zero (linear model: WLOG)
    e=g.standard_normal((len(sd),N_MC))*sd[:,None]
    est=Pinv@(e/sd[:,None])
    ex,ey=est[dx]*1e6, est[dy]*1e6
    return float(np.mean(np.abs(ex)<T)), float(np.mean(np.hypot(ex,ey)<T))

def probs(C):
    C2=np.array([[C[dx,dx],C[dx,dy]],[C[dy,dx],C[dy,dy]]])*1e12      # urad^2
    sx,sy=sqrt(C2[0,0]),sqrt(C2[1,1])
    p1=erf(T/(sqrt(2)*sx))                                           # one axis
    ev=np.linalg.eigvalsh(C2)
    n=200000; rng=np.random.default_rng(7)
    L=np.linalg.cholesky(C2+1e-18*np.eye(2))
    e=(L@rng.standard_normal((2,n)))
    p2=float(np.mean(np.hypot(e[0],e[1])<T))                         # two-axis magnitude
    return sx,sy,p1,p2
res={"tolerance_urad":round(T,4),"f_focal_m":4.0,"sigma_cam_m":5e-6,"n_monte_carlo":N_MC,
     "note":"sigma is the Cramer-Rao bound. P_* are the Gaussian efficient-estimator reliability "
            "benchmark under the assumed linear-Gaussian model. P_*_mc are a direct weighted "
            "least-squares Monte Carlo under the same model."}
best={}
print(f"tolerance {T:.3f} urad")
print(f"{'k':>2} {'sigma_x':>9} {'P1(bench)':>10} {'P2(bench)':>10} {'P1(WLS MC)':>10} {'P2(WLS MC)':>10}   best subset")
for k in range(1,13):
    b=(1e18,None)
    for c in itertools.combinations(range(len(snames)),k):
        C=cov(c)
        if C is None: continue
        s=max(C[dx,dx],C[dy,dy])
        if s<b[0]: b=(s,c)
    C=cov(b[1]); sx,sy,p1,p2=probs(C)
    m1,m2=wls_mc(b[1])
    res[k]={"planes":[snames[i] for i in b[1]],"sigma_x_urad":round(sx,3),"sigma_y_urad":round(sy,3),
            "P_one_axis":round(p1,4),"P_two_axis":round(p2,4),
            "P_one_axis_mc":round(m1,4),"P_two_axis_mc":round(m2,4)}
    print(f"{k:>2} {sx:>9.3f} {p1:>10.4f} {p2:>10.4f} {m1:>10.4f} {m2:>10.4f}   {[snames[i] for i in b[1]]}")
mx1=max(abs(res[k]["P_one_axis"]-res[k]["P_one_axis_mc"]) for k in range(1,13))
mx2=max(abs(res[k]["P_two_axis"]-res[k]["P_two_axis_mc"]) for k in range(1,13))
res["max_benchmark_vs_mc_deviation"]={"one_axis":round(mx1,4),"two_axis":round(mx2,4)}
print(f"  benchmark vs WLS Monte Carlo: max deviation {mx1:.4f} (one axis), {mx2:.4f} (two axis)")
for tgt in (0.90,0.95):
    for key,lab in (("P_one_axis_mc","one-axis"),("P_two_axis_mc","two-axis")):
        ks=[k for k in range(1,13) if res[k][key]>=tgt]
        res[f"k_for_{int(tgt*100)}_{lab}"]=ks[0] if ks else None
        print(f"  channels for {int(tgt*100)}% ({lab}): {ks[0] if ks else '>12'}")
json.dump(res,open(artifact("v5_reliability.json"),"w"),indent=1)
